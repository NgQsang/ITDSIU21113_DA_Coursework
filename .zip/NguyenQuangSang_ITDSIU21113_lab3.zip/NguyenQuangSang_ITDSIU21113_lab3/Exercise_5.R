#script code and lap report by comment in Exercise 5

na_count <- sum(is.na(data_metro_zip_new))
print(na_count)
#there is 1104796 NA values in this dataset
#script code and lap report by comment in Exercise 6

#replace all NA with 0 in the data_metro_zip.
data_metro_zip_new[is.na(data_metro_zip_new)] <- 0
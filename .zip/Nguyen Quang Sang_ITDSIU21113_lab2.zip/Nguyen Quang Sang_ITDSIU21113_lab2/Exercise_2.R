#lap report by comment in Exercise 2

#In my opinion, I think this is the untidy data
#because for the following reason:

#1) quick look at the dataset in Excel you can see that
#the two columns "state name" and "state" are too redundant(A lot of data is duplicated)
#the value of these two col are the same

#2) quick look at, you can see that data is too wide, all the date value is messy
#the extraneous data "X" precedes the data of the date column
#They should be combined into 1 column, and reformat
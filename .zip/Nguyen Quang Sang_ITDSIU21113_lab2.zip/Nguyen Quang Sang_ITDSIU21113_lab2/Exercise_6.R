#script code and lap report by comment in Exercise 6

write.csv(data_filtered, file = "filtered_data.csv", row.names = FALSE)